export let configFTP = {
	host: "files.000webhost.com", // Адрес для FTP сервера
	user: "alex13slem", // Имя пользователя
	password: "Alex995344", // Пароль
	parallel: 5 // Кол-во одновременных потоков
}